<?php
/**
 * @version		$Id: pp_button.php 3755 2014-10-02 08:55:51Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['heading_title']			= 'PayPal Express Checkout Button';

$_['text_module']			= 'Module';
$_['text_success']			= 'Modul erfolgreich bearbeitet';
$_['text_edit']				= 'Bearbeiten';

$_['entry_status']			= 'Status';

$_['error_permission']		= 'Keine Rechte f�r diese Aktion';