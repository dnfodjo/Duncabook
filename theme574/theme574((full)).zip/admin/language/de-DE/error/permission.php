<?php
/**
 * @version		$Id: permission.php 3488 2013-11-28 13:46:37Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']		= 'Zugriff verweigert!';

// Text
$_['text_permission']	= 'Keine Rechte für den Zugriff auf diese Seite, bitte Admin kontaktieren.';