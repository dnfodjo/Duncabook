<?php
// Text
$_['text_subject']       = '%s - Return Update %s';
$_['text_return_id']     = 'Return ID:';
$_['text_date_added']    = 'Return Date:';
$_['text_return_status'] = 'Your return has been updated to the following status:';
$_['text_comment']       = 'The comments for your return are:';
$_['text_footer']        = 'Please reply to this email if you have any questions.';