<?php
// Heading
$_['heading_title'] = 'Tm Module Tabs';
$_['heading_latest'] = 'Latest';
$_['heading_specials'] = 'Specials';
$_['heading_featured'] = 'Featured';
$_['heading_bestsellers'] = 'Bestsellers';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_sale']      = 'Sale!';
