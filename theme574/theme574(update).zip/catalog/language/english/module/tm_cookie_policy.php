<?php
// Heading
$_['heading_title'] = 'Cookie Policy';
$_['text_cookie_close']      = 'Close';
$_['text_cookie']            = 'We use cookies to offer you the best experience on our site. By continuing to browse the site, you agree to use cookies.';