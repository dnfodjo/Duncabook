<?php

/* Language file for MultiMerch Badges Addon */

$_['ms_account_badges'] = 'Badges';
$_['ms_account_badges_nobadges'] = 'No badges yet';

?>
