<?php

/* Language file for MultiMerch Top Sellers Addon */

$_['ms_topsellers_sellers'] = 'Top sellers';
$_['ms_topsellers_view'] = 'View all sellers';

?>
