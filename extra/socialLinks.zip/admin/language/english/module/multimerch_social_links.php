<?php

$_['heading_title']    = '<b>[MultiMerch]</b> Social Links';
$_['heading_subtitle'] = 'Social Media Links';
$_['text_module'] = 'Modules';
$_['entry_status'] = 'Status';
$_['ms_menu_social_links'] = 'Social links';

$_['ms_sl_enable_channels'] = 'Enable social channels';
$_['ms_sl_icon_size'] = 'Icon size';

$_['ms_sl'] = 'Social links';
$_['ms_sl_manage'] = 'Manage social channels';
$_['ms_sl_create'] = 'New social channel';
$_['ms_sl_update'] = 'Update social channel';

$_['ms_sl_column_id'] = 'ID';
$_['ms_sl_column_name'] = 'Name';
$_['ms_sl_image'] = 'Image';
$_['ms_sl_column_action'] = 'Action';
$_['ms_success_channel_created'] = 'Social channel created';
$_['ms_success_channel_updated'] = 'Social channel updated';
$_['ms_error_channel_name'] = 'Please specify a name for the social channel';

?>