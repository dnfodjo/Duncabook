<?php

$_['ms_sl_social_media'] = 'Social Media';
$_['ms_sl_facebook'] = 'Facebook';
$_['ms_sl_twitter'] = 'Twitter';
$_['ms_sl_google'] = 'Google+';
$_['ms_sl_tumblr'] = 'Tumblr';
$_['ms_sl_pinterest'] = 'Pinterest';
$_['ms_sl_linkedin'] = 'Linkedin';
$_['ms_sl_dribble'] = 'Dribble';
$_['ms_sl_skype'] = 'Skype';

?>