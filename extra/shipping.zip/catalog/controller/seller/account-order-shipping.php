<?php

class ControllerSellerAccountOrderShipping extends ControllerSellerAccount {
}

?>
