<?php

$_['heading_title']    = '[MultiMerch] Shipping System';
$_['text_module']         = 'Modules';

?>
