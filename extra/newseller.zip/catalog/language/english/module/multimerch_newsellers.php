<?php

/* Language file for MultiMerch New Sellers Addon */

$_['ms_newsellers_sellers'] = 'New sellers';
$_['ms_newsellers_view'] = 'View all sellers';

?>
