<?php
$_['ppa_title']    = 'PayPal Adaptive';
$_['ppa_sandbox']	= 'Warning: The payment gateway is in \'Sandbox Mode\'. Your account will not be charged.';
$_['ppa_wait']        = 'Please wait!';

$_['ppa_error_distribution']        = 'Configuration Error: Invalid Amount Distribution. Order ID: %s';
$_['ppa_error_noreceivers']        = 'Configuration Error: No valid receivers specified. Order ID: %s';
$_['ppa_error_generic']        = 'Configuration Error: Please contact the store owner. Order ID: %s';
$_['ppa_error_request']        = 'PayPal Request Error: Correlation ID %s';
$_['ppa_error_response']        = 'PayPal Response Error: Status %s Correlation ID: %s';

$_['ms_transaction_order'] = 'Sale: Order Id #%s';
?>